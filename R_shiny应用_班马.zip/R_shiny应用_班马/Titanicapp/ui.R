shinyUI(fluidPage(
  titlePanel(strong("Predict survival on the Titanic")),
  
  sidebarLayout(
    sidebarPanel(
      helpText("On April 15, 1912,  
                the Titanic sank after colliding with an iceberg, 
                killing 1502 out of 2224 passengers and crew.
                It is one of the most infamous shipwrecks in history
                here is a app for Predict survival on the Titanic.
                Please choose the choice and Good Luck!"),
      
      
      selectInput("sex",  
                  label = "1.Choose sex",
                  choices =c("female", "male")
                  
                  ),
      numericInput("class", 
                   label = "3.Input  class", 1
      ),
      numericInput("age", 
                   label = "3.Input  age", 30
                   ),
      numericInput("sibsp", 
                   label = "4.Input  sibsp", value = 0),
      numericInput("parch", 
                   label = "5.Input  parch", value = 0),
      numericInput("Fare", 
                   label = "6.Input  Fare", value = 0 ),
      selectInput("Embarked",  
                  label = "7.choose Embarked", choices =c("C", "Q","S")),
     # sliderInput("range", 
     #             label = "Range of interest:",
    #            min = 0, max = 100, value = c(0, 100)),
      submitButton("Update View")
    ),
    
    mainPanel(
              h5(strong("You have selected:")),
              br(tableOutput("table")),
              strong(textOutput("text2")),
              #br(),
              span(strong(textOutput("text")),style = "color:red")
              #span("RStudio", style = "color:blue")
      )
  )
))