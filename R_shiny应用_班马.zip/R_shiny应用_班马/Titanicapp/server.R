# server.R
#submit <- data.frame(PassengerId = test$PassengerId, Survived = Prediction)

library(rpart)
#library('dplyr') # 数据处理
train<- read.csv("./data/train.csv")

fit <- rpart(Survived ~ Pclass + Sex  + Age + SibSp + Parch + Fare + Embarked
             ,
             data=train,
             method="class", 
             control=rpart.control(minsplit=2, cp=0))

shinyServer(function(input, output) {
  
  sliderValues<-reactive({
          data.frame(
                   #Survived=NA,
                   Sex=factor(input$sex,levels=c("male","female")),
                   Pclass=input$class,
                   Age=input$age,
                   SibSp=input$sibsp,
                   Parch=input$parch,
                   Fare=input$Fare,
                   Embarked=factor(input$Embarked, levels=c("C","Q","S")),
                   #Value=as.character(
                    # c(
                     #input$pclass,
                     #input$sex,
                     #input$age#,
                     #input$sibsp,
                     #input$parch,
                     #input$Fare,
                     #input$Embarked,
                  stringsAsFactors=FALSE
                      )
          })
  # output$text1 <- renderText
 # ({ 
    
  #  paste("You have selected:"," ")
          
  
  #  })
  output$table <- renderTable({
    sliderValues()
  })
  
  output$text2<- renderText({
   paste("Prediction of survival on the Titanic（1:survived，0:died）：")
  })
  
  output$text<- renderText({
    paste(predict(fit, sliderValues(), type = "class"))
  })
  
  })


  
# output$text3 <- renderText({ 
#   paste("You have selected age:", input$age)
# })
#  output$text2 <- renderText({ 
#   paste("You have chosen a range that goes from",
#   input$range[1], "to", input$range[2])
  
  
  
#})

#shinyServer(
# function(input, output) {
    
#   output$text1 <- renderText({ #用 render*函数 （server.R script）告诉shiny如何制作对象
#     paste("You have selected", input$var)
#   })
    
#   output$text2 <- renderText({ #用*Output 函数 （ui.R script）来放置反馈对象
#     paste("You have chosen a range that goes from",
#           input$range[1], "to", input$range[2])
#   })
#   
# }
#)

#用*Output 函数 （ui.R script）来放置反馈对象。
#用 render*函数 （server.R script）告诉shiny如何制作对象。
#R表达式用{}包围render* 函数
#保存 render* expressions 在输出表单中，与反馈对象一一对应。
#常见反馈用input 和 render* expression
#如果你遵循以上法则，Shiny就会自动呈现反馈表达式。