library(shiny)
runApp('D:/Data-Analysis/R/R_shiny/testapp/Titanicapp')