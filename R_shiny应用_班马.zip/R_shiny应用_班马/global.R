library(shiny)
library(rpart)
train<- read.csv("./data/train.csv")

fit <- rpart(Survived ~ Pclass + Sex  + Age + SibSp + Parch + Fare + Embarked
             ,
             data=train,
             method="class", 
             control=rpart.control(minsplit=2, cp=0))
